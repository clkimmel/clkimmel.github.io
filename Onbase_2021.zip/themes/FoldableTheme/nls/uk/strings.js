define({
  "_themeLabel": "Тема Foldable",
  "_layout_default": "Компонування за замовчуванням",
  "_layout_layout1": "Компонування 1"
});