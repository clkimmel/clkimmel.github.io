define({
  "_themeLabel": "Tema Plegable",
  "_layout_default": "Disseny per defecte",
  "_layout_layout1": "Disseny 1"
});