define({
  "_widgetLabel": "머리글 컨트롤러",
  "signin": "로그인",
  "signout": "로그아웃",
  "about": "정보",
  "signInTo": "로그인:",
  "cantSignOutTip": "이 기능은 미리보기 모드가 제공되지 않습니다.",
  "more": "기타"
});